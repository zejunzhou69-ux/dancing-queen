﻿# Dancing Queen · 念珠手作 v2.1

Handcrafted Chinese incense bead bracelets.

## 联系方式

- WeChat: abc568347492
- WhatsApp: +86 13738901892
- Phone: +86 13738901892

## 网站

Dancing Queen · 念珠手作 - 合香珠手链 v2.1

---

© 2025 Dancing Queen Atelier
